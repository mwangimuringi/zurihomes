<script setup>
import PropertyList from './components/PropertyList.vue'
</script>

<template>
  <main>
  <PropertyList />
  </main>
</template>